[**starkzap**](../README.md)

***

[starkzap](../globals.md) / getPresets

# Function: getPresets()

> **getPresets**(`chainId`): `Record`\<`string`, [`Token`](../interfaces/Token.md)\>

Defined in: [src/erc20/token/index.ts:11](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/erc20/token/index.ts#L11)

## Parameters

### chainId

[`ChainId`](../classes/ChainId.md)

## Returns

`Record`\<`string`, [`Token`](../interfaces/Token.md)\>
