[**starkzap**](../README.md)

***

[starkzap](../globals.md) / OnboardStrategy

# Type Alias: OnboardStrategy

> **OnboardStrategy** = *typeof* [`OnboardStrategy`](../variables/OnboardStrategy.md)\[keyof *typeof* [`OnboardStrategy`](../variables/OnboardStrategy.md)\]

Defined in: [src/types/onboard.ts:21](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/types/onboard.ts#L21)
