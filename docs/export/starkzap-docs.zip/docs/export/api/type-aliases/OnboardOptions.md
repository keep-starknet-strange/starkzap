[**starkzap**](../README.md)

***

[starkzap](../globals.md) / OnboardOptions

# Type Alias: OnboardOptions

> **OnboardOptions** = [`OnboardSignerOptions`](../interfaces/OnboardSignerOptions.md) \| [`OnboardPrivyOptions`](../interfaces/OnboardPrivyOptions.md) \| [`OnboardCartridgeOptions`](../interfaces/OnboardCartridgeOptions.md)

Defined in: [src/types/onboard.ts:74](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/types/onboard.ts#L74)
