[**starkzap**](../README.md)

***

[starkzap](../globals.md) / ExplorerProvider

# Type Alias: ExplorerProvider

> **ExplorerProvider** = `"voyager"` \| `"starkscan"`

Defined in: [src/types/config.ts:108](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/types/config.ts#L108)

Supported block explorer providers
