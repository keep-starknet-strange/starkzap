[**starkzap**](../README.md)

***

[starkzap](../globals.md) / TransactionExecutionStatus

# Type Alias: TransactionExecutionStatus

> **TransactionExecutionStatus** = `RPC$1.ETransactionExecutionStatus`

Defined in: node\_modules/starknet/dist/index.d.ts:589
