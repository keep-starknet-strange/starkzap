[**starkzap**](../README.md)

***

[starkzap](../globals.md) / PreparedTransaction

# Type Alias: PreparedTransaction

> **PreparedTransaction** = `PreparedDeployTransaction` \| `PreparedInvokeTransaction` \| `PreparedDeployAndInvokeTransaction`

Defined in: node\_modules/starknet/dist/index.d.ts:1016
