[**starkzap**](../README.md)

***

[starkzap](../globals.md) / TransactionFinalityStatus

# Type Alias: TransactionFinalityStatus

> **TransactionFinalityStatus** = `RPC$1.ETransactionFinalityStatus`

Defined in: node\_modules/starknet/dist/index.d.ts:583
