[**starkzap**](../README.md)

***

[starkzap](../globals.md) / NetworkName

# Type Alias: NetworkName

> **NetworkName** = keyof *typeof* [`networks`](../variables/networks.md)

Defined in: [src/network/presets.ts:55](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/network/presets.ts#L55)
