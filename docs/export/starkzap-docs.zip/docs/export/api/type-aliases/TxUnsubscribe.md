[**starkzap**](../README.md)

***

[starkzap](../globals.md) / TxUnsubscribe

# Type Alias: TxUnsubscribe()

> **TxUnsubscribe** = () => `void`

Defined in: [src/types/tx.ts:44](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/types/tx.ts#L44)

Function to stop watching (returned by `tx.watch()`)

## Returns

`void`
