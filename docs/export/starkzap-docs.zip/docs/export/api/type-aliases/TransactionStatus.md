[**starkzap**](../README.md)

***

[starkzap](../globals.md) / TransactionStatus

# Type Alias: TransactionStatus

> **TransactionStatus** = `RPC.ETransactionStatus`

Defined in: node\_modules/starknet/dist/index.d.ts:554
