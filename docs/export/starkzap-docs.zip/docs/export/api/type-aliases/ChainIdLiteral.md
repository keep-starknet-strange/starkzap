[**starkzap**](../README.md)

***

[starkzap](../globals.md) / ChainIdLiteral

# Type Alias: ChainIdLiteral

> **ChainIdLiteral** = `"SN_MAIN"` \| `"SN_SEPOLIA"`

Defined in: [src/types/config.ts:11](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/types/config.ts#L11)

Supported Starknet chain identifiers
