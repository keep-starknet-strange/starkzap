[**starkzap**](../README.md)

***

[starkzap](../globals.md) / ArgentPreset

# Variable: ArgentPreset

> `const` **ArgentPreset**: [`AccountClassConfig`](../interfaces/AccountClassConfig.md)

Defined in: [src/account/presets.ts:38](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/account/presets.ts#L38)

Argent account preset (v0.4.0).
Uses CairoCustomEnum for the owner signer.
