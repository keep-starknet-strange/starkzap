[**starkzap**](../README.md)

***

[starkzap](../globals.md) / OnboardStrategy

# Variable: OnboardStrategy

> `const` **OnboardStrategy**: `object`

Defined in: [src/types/onboard.ts:21](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/types/onboard.ts#L21)

## Type Declaration

### Signer

> `readonly` **Signer**: `"signer"` = `"signer"`

### Privy

> `readonly` **Privy**: `"privy"` = `"privy"`

### Cartridge

> `readonly` **Cartridge**: `"cartridge"` = `"cartridge"`
