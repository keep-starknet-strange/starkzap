[**starkzap**](../README.md)

***

[starkzap](../globals.md) / mainnet

# Variable: mainnet

> `const` **mainnet**: [`NetworkPreset`](../interfaces/NetworkPreset.md)

Defined in: [src/network/presets.ts:20](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/network/presets.ts#L20)

Starknet Mainnet configuration.
