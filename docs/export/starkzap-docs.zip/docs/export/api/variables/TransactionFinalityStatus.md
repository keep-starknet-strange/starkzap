[**starkzap**](../README.md)

***

[starkzap](../globals.md) / TransactionFinalityStatus

# Variable: TransactionFinalityStatus

> **TransactionFinalityStatus**: `object`

Defined in: node\_modules/starknet/dist/index.d.ts:583

## Type Declaration

### PRE\_CONFIRMED

> `readonly` **PRE\_CONFIRMED**: `"PRE_CONFIRMED"`

### ACCEPTED\_ON\_L2

> `readonly` **ACCEPTED\_ON\_L2**: `"ACCEPTED_ON_L2"`

### ACCEPTED\_ON\_L1

> `readonly` **ACCEPTED\_ON\_L1**: `"ACCEPTED_ON_L1"`
