[**starkzap**](../README.md)

***

[starkzap](../globals.md) / DevnetPreset

# Variable: DevnetPreset

> `const` **DevnetPreset**: [`AccountClassConfig`](../interfaces/AccountClassConfig.md)

Defined in: [src/account/presets.ts:14](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/account/presets.ts#L14)

Devnet account preset.
Uses the pre-declared account class on starknet-devnet.
