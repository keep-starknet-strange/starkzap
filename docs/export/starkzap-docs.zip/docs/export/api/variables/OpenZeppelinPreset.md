[**starkzap**](../README.md)

***

[starkzap](../globals.md) / OpenZeppelinPreset

# Variable: OpenZeppelinPreset

> `const` **OpenZeppelinPreset**: [`AccountClassConfig`](../interfaces/AccountClassConfig.md)

Defined in: [src/account/presets.ts:25](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/account/presets.ts#L25)

OpenZeppelin account preset.
