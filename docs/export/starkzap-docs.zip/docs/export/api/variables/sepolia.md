[**starkzap**](../README.md)

***

[starkzap](../globals.md) / sepolia

# Variable: sepolia

> `const` **sepolia**: [`NetworkPreset`](../interfaces/NetworkPreset.md)

Defined in: [src/network/presets.ts:30](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/network/presets.ts#L30)

Starknet Sepolia Testnet configuration.
