[**starkzap**](../README.md)

***

[starkzap](../globals.md) / PaymasterTimeBounds

# Interface: PaymasterTimeBounds

Defined in: node\_modules/starknet/dist/index.d.ts:1070

## Properties

### executeAfter?

> `optional` **executeAfter**: `number`

Defined in: node\_modules/starknet/dist/index.d.ts:1071

***

### executeBefore

> **executeBefore**: `number`

Defined in: node\_modules/starknet/dist/index.d.ts:1072
