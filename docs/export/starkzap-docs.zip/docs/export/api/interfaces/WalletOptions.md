[**starkzap**](../README.md)

***

[starkzap](../globals.md) / WalletOptions

# Interface: WalletOptions

Defined in: [src/wallet/index.ts:53](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L53)

Options for creating a Wallet.

## Properties

### account

> **account**: [`AccountProvider`](../classes/AccountProvider.md) \| \{ `signer`: [`SignerInterface`](SignerInterface.md); `accountClass?`: [`AccountClassConfig`](AccountClassConfig.md); \}

Defined in: [src/wallet/index.ts:55](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L55)

Account: either AccountProvider or { signer, accountClass? }

***

### provider

> **provider**: `RpcProvider`

Defined in: [src/wallet/index.ts:59](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L59)

RPC provider

***

### config

> **config**: [`SDKConfig`](SDKConfig.md)

Defined in: [src/wallet/index.ts:61](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L61)

SDK configuration

***

### accountAddress?

> `optional` **accountAddress**: [`Address`](../type-aliases/Address.md)

Defined in: [src/wallet/index.ts:63](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L63)

Known address (skips address computation if provided)

***

### feeMode?

> `optional` **feeMode**: [`FeeMode`](../type-aliases/FeeMode.md)

Defined in: [src/wallet/index.ts:65](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L65)

Default fee mode (default: "user_pays")

***

### timeBounds?

> `optional` **timeBounds**: [`PaymasterTimeBounds`](PaymasterTimeBounds.md)

Defined in: [src/wallet/index.ts:67](https://github.com/keep-starknet-strange/x/blob/5e54d8974744c392df7cac56b636788dfe6ae268/src/wallet/index.ts#L67)

Default time bounds for paymaster transactions
