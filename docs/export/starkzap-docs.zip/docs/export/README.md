# Exported Documentation

- Start with `DEVELOPER_GUIDE.md` for onboarding and workflows.
- Use `api/README.md` for the generated API reference.
- `manifest.json` contains package version and export timestamp.
