[**x**](../README.md)

***

[x](../globals.md) / DevnetPreset

# Variable: DevnetPreset

> `const` **DevnetPreset**: [`AccountClassConfig`](../interfaces/AccountClassConfig.md)

Defined in: [src/account/presets.ts:14](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/account/presets.ts#L14)

Devnet account preset.
Uses the pre-declared account class on starknet-devnet.
