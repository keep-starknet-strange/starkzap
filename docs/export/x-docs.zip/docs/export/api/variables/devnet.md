[**x**](../README.md)

***

[x](../globals.md) / devnet

# Variable: devnet

> `const` **devnet**: [`NetworkPreset`](../interfaces/NetworkPreset.md)

Defined in: [src/network/presets.ts:40](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/network/presets.ts#L40)

Local devnet configuration (using starknet-devnet-rs defaults).
