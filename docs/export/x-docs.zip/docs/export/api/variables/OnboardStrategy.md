[**x**](../README.md)

***

[x](../globals.md) / OnboardStrategy

# Variable: OnboardStrategy

> `const` **OnboardStrategy**: `object`

Defined in: src/types/onboard.ts:7

## Type Declaration

### Signer

> `readonly` **Signer**: `"signer"` = `"signer"`

### Privy

> `readonly` **Privy**: `"privy"` = `"privy"`

### Cartridge

> `readonly` **Cartridge**: `"cartridge"` = `"cartridge"`

### WebAuthn

> `readonly` **WebAuthn**: `"webauthn"` = `"webauthn"`
