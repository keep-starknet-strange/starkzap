[**x**](../README.md)

***

[x](../globals.md) / sepolia

# Variable: sepolia

> `const` **sepolia**: [`NetworkPreset`](../interfaces/NetworkPreset.md)

Defined in: [src/network/presets.ts:30](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/network/presets.ts#L30)

Starknet Sepolia Testnet configuration.
