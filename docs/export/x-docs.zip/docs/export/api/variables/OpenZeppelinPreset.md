[**x**](../README.md)

***

[x](../globals.md) / OpenZeppelinPreset

# Variable: OpenZeppelinPreset

> `const` **OpenZeppelinPreset**: [`AccountClassConfig`](../interfaces/AccountClassConfig.md)

Defined in: [src/account/presets.ts:25](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/account/presets.ts#L25)

OpenZeppelin account preset.
