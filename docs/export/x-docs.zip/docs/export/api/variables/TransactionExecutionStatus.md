[**x**](../README.md)

***

[x](../globals.md) / TransactionExecutionStatus

# Variable: TransactionExecutionStatus

> **TransactionExecutionStatus**: `object`

Defined in: node\_modules/starknet/dist/index.d.ts:589

## Type Declaration

### SUCCEEDED

> `readonly` **SUCCEEDED**: `"SUCCEEDED"`

### REVERTED

> `readonly` **REVERTED**: `"REVERTED"`
