[**x**](../README.md)

***

[x](../globals.md) / PreflightResultOk

# Interface: PreflightResultOk

Defined in: [src/types/wallet.ts:178](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/types/wallet.ts#L178)

Preflight succeeded — operation can proceed

## Properties

### ok

> **ok**: `true`

Defined in: [src/types/wallet.ts:179](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/types/wallet.ts#L179)
