[**x**](../README.md)

***

[x](../globals.md) / getPresets

# Function: getPresets()

> **getPresets**(`chainId`): `Record`\<`string`, [`Token`](../interfaces/Token.md)\>

Defined in: [src/erc20/token/index.ts:11](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/erc20/token/index.ts#L11)

## Parameters

### chainId

[`ChainId`](../classes/ChainId.md)

## Returns

`Record`\<`string`, [`Token`](../interfaces/Token.md)\>
