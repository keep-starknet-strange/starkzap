[**x**](../README.md)

***

[x](../globals.md) / OnboardStrategy

# Type Alias: OnboardStrategy

> **OnboardStrategy** = *typeof* [`OnboardStrategy`](../variables/OnboardStrategy.md)\[keyof *typeof* [`OnboardStrategy`](../variables/OnboardStrategy.md)\]

Defined in: src/types/onboard.ts:7
