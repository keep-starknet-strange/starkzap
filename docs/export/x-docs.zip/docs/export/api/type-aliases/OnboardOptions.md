[**x**](../README.md)

***

[x](../globals.md) / OnboardOptions

# Type Alias: OnboardOptions

> **OnboardOptions** = [`OnboardSignerOptions`](../interfaces/OnboardSignerOptions.md) \| [`OnboardPrivyOptions`](../interfaces/OnboardPrivyOptions.md) \| [`OnboardCartridgeOptions`](../interfaces/OnboardCartridgeOptions.md) \| [`OnboardWebAuthnOptions`](../interfaces/OnboardWebAuthnOptions.md)

Defined in: src/types/onboard.ts:55
