[**x**](../README.md)

***

[x](../globals.md) / ExplorerProvider

# Type Alias: ExplorerProvider

> **ExplorerProvider** = `"voyager"` \| `"starkscan"`

Defined in: [src/types/config.ts:108](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/types/config.ts#L108)

Supported block explorer providers
