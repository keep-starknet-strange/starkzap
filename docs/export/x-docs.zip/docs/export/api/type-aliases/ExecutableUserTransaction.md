[**x**](../README.md)

***

[x](../globals.md) / ExecutableUserTransaction

# Type Alias: ExecutableUserTransaction

> **ExecutableUserTransaction** = `ExecutableDeployTransaction` \| `ExecutableInvokeTransaction` \| `ExecutableDeployAndInvokeTransaction`

Defined in: node\_modules/starknet/dist/index.d.ts:1058
