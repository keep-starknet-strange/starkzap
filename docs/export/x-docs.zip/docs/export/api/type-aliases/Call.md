[**x**](../README.md)

***

[x](../globals.md) / Call

# Type Alias: Call

> **Call** = `CallDetails` & `object`

Defined in: node\_modules/starknet/dist/index.d.ts:741

## Type Declaration

### entrypoint

> **entrypoint**: `string`
