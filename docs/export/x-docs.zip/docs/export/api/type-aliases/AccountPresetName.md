[**x**](../README.md)

***

[x](../globals.md) / AccountPresetName

# Type Alias: AccountPresetName

> **AccountPresetName** = keyof *typeof* [`accountPresets`](../variables/accountPresets.md)

Defined in: [src/account/presets.ts:116](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/account/presets.ts#L116)
