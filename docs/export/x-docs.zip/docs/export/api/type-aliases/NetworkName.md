[**x**](../README.md)

***

[x](../globals.md) / NetworkName

# Type Alias: NetworkName

> **NetworkName** = keyof *typeof* [`networks`](../variables/networks.md)

Defined in: [src/network/presets.ts:55](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/network/presets.ts#L55)
