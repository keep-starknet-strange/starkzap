[**x**](../README.md)

***

[x](../globals.md) / ChainIdLiteral

# Type Alias: ChainIdLiteral

> **ChainIdLiteral** = `"SN_MAIN"` \| `"SN_SEPOLIA"`

Defined in: [src/types/config.ts:11](https://github.com/keep-starknet-strange/x/blob/a5957e5a6aebb4214574da0d6c8fb4a586de1aa2/src/types/config.ts#L11)

Supported Starknet chain identifiers
