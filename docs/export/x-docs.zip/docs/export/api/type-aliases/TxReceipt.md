[**x**](../README.md)

***

[x](../globals.md) / TxReceipt

# Type Alias: TxReceipt

> **TxReceipt** = `SuccessfulTransactionReceiptResponseHelper` \| `RevertedTransactionReceiptResponseHelper` \| `ErrorReceiptResponseHelper`

Defined in: node\_modules/starknet/dist/index.d.ts:1803
